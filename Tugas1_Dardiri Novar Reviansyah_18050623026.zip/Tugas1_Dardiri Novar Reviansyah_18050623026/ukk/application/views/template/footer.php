     <!-- AWALAN FOOTER-->
     <aside class="aside-menu">
    </div>
    </aside>
    <footer class="app-footer">
      <div>
        <a href="#">UKK</a>
        <span>&copy; 2019 .</span>
      </div>
      <div class="ml-auto">
        <span>DI</span>
        <a href="#">SMK NURUL JADID</a>
      </div>
    </footer>
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="node_modules/pace-progress/pace.min.js"></script>
    <script src="node_modules/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
    <script src="node_modules/@coreui/coreui/dist/js/coreui.min.js"></script>
  </body>
</html>
<!-- AKHIR FOOTER-->